Heuristic Function Used: For monitor problem I used the heuristic of the sum of euclidean distances between the all the sensors and all the targets.
For the aggregation problem I used a different version of the problem

This is version one of my puzzlesolver.py and I would like to submit an additional file before midnight

Python Version: 2.7
Python Libraries: scipy.spatial
Materials Used: Python Docs, YouTube (Searched 'Bill Gates Pancake Problem'), Stack Overflow for assistance on implementing Python features
Persons Discussed: N/A
Anything Not Working?
  I did not attempt to solve the pancake solution, however all search strategies were working for the first
  two problems


For the monitor problem, the configuration with the longest monitoring time is the goal state
For the aggregation problem, the path with the shortest time delay is the goal state
For the pancake problem, the configuration of pancakes with every pancake in order is the goal state

The heuristic for the monitor problem is the sum of the euclidean distance between the sensors and targets
The heuristic for the aggregation problem of the data aggregation is the
